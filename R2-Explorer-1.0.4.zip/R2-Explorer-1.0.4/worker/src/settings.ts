export const config = {
    raiseUnknownParameters: true,
    generateOperationIds: false,
    version: '0.0.1'
}
