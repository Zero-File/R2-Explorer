import { R2Explorer } from 'r2-explorer';

export default R2Explorer({ readonly: true });
