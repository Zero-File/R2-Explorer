<template>
  <!-- Left sidebar -->
  <!--      <div class="inbox-leftbar">-->

  <!--        <a href="email-compose.html" class="btn btn-danger w-100 waves-effect waves-light">Compose</a>-->

  <!--        <div class="mail-list mt-4">-->
  <!--          <a href="javascript: void(0);" class="text-danger fw-bold"><i class="bi bi-inbox"></i> Inbox<span-->
  <!--            class="badge badge-soft-danger float-end ms-2">7</span></a>-->
  <!--          <a href="javascript: void(0);"><i class="bi bi-trash3"></i> Trash</a>-->
  <!--        </div>-->

  <!--        <h6 class="mt-4">Labels</h6>-->

  <!--        <div class="list-group b-0 mail-list">-->
  <!--          <a href="#" class="list-group-item border-0"><span class="mdi mdi-circle text-info me-2"></span>Web App</a>-->
  <!--          <a href="#" class="list-group-item border-0"><span-->
  <!--            class="mdi mdi-circle text-warning me-2"></span>Recharge</a>-->
  <!--          <a href="#" class="list-group-item border-0"><span class="mdi mdi-circle text-dark me-2"></span>Wallet Balance</a>-->
  <!--          <a href="#" class="list-group-item border-0"><span class="mdi mdi-circle text-primary me-2"></span>Friends</a>-->
  <!--          <a href="#" class="list-group-item border-0"><span class="mdi mdi-circle text-success me-2"></span>Family</a>-->
  <!--        </div>-->

  <!--      </div>-->
  <!-- End Left sidebar -->
</template>
